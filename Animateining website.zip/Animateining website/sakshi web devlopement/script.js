// Trigger animations after DOM is ready.
// Keeps CSS stagger behavior smooth and avoids flicker on reload.

document.addEventListener('DOMContentLoaded', () => { const root = document.documentElement;

  // Year in footer
const year = document.getElementById('year');
if (year) year.textContent = String(new Date().getFullYear());

  // Start continuous motion after initial load animations
  // Small delay so the entrance animation is perceived first.
setTimeout(() => {
    root.setAttribute('data-anim-state', 'play');
}, 900);
});

